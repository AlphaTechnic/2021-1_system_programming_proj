+---------------------------------------------------------------------+

    HOW TO EXECUTE
    1. Enter the 'make' command to compile.
       Then, the 'myshell.out' executable file is created.
    2. Enter the './myshell.out' command to run the 'myshell.out' file.
    3. If you want to delete the object file and the executable file,
       run the 'make clean' command.

+---------------------------------------------------------------------+
