/* $begin shellmain */
#include "myshell.h"

int main() {
    char cmdline[MAXLINE]; /* Command line */

    while (1) {
        /* Read */
        printf("CSE4100-SP-P#4> ");
        char* foo = fgets(cmdline, MAXLINE, stdin);
        if (feof(stdin))
            exit(0);

        /* Evaluate */
        eval(cmdline);
    }
}
/* $end shellmain */

/* $begin eval */
/* eval - Evaluate a command line */
void eval(char *cmdline) {
    char *argv[MAXARGS]; /* Argument list execve() */
    char buf[MAXLINE];   /* Holds modified command line */
    int bg;              /* Should the job pipe_command in bg or fg? */
    pid_t pid;           /* Process id */

    // for phase 1
    int argc;

    // for phase 2
    PCMD_TYPE cmd_type = FIRST;
    int p_flag = 0;
    int input = 0;

    strcpy(buf, cmdline);
    bg = parseline(buf, &argc, argv);

    // is pipelined?
    char* cmd = cmdline;
    char cmdline_cpy[MAXLINE];
    strcpy(cmdline_cpy, cmdline);
    char* bar_pos;
    if ((bar_pos = strchr(cmd, '|')) != NULL) {
        p_flag = 1;
    }

    if (argv[0] == NULL)
        return;   /* Ignore empty lines */

    if (!builtin_command(argc, argv)) { // quit -> exit(0), & -> ignore, other -> pipe_command
        if (!p_flag) { // 단일 명령
            if ((pid = fork()) == 0) { // child process
                if (execvp(argv[0], argv) < 0){
                    printf("Err! There's no command : \"%s\"\n", argv[0]);
                    fflush(stdout);
                    exit(0);
                }
            }

            // foreground job이면 곧바로 wait
            if (!bg){
                while(wait(NULL) > 0);
            }
        }

        // pipeline command
        // pipe structure : FIRST - MIDDLE - ... - MIDDLE - LAST
        else {
            while (bar_pos != NULL) {
                *bar_pos = '\0';

                // execute pipe command
                input = pipe_command(cmd, argv, input, cmd_type, &pid);

                cmd = bar_pos + 1;
                bar_pos = strchr(cmd, '|');
                cmd_type = MIDDLE;
            }
            // &가 붙은 background command일 경우, &를 제거하고 parameter로 넘겨줌
            char* ptr;
            if ((ptr = (strchr(cmd, '&')))) *ptr = '\0';
            pipe_command(cmd, argv, input, LAST, &pid);

            // foreground job이면 바로 wait
            if (!bg){
                while(wait(NULL) > 0);
            }
        }
    }
}

/* If first arg is a builtin command, run it and return true */
int builtin_command(int argc, char **argv) {
    char *cmd = argv[0];
    if (!strcmp(argv[0], "quit") || (!strcmp(argv[0], "exit"))) { /* quit command */
        exit(0);
    }
    if (!strcmp(argv[0], "&"))    /* Ignore singleton & */
        return 1;

    if (strcmp(argv[0], "cd") == 0) {
        change_dir(argc, argv);
        return 1;
    }
    return 0;                     /* Not a builtin command */
}

/* $end eval */

/* $begin parseline */
/* parseline - Parse the command line and build the argv array */
int parseline(char *buf, int *argc, char **argv) {
    char *delim;         /* Points to first space delimiter */
    //int argc;            /* Number of args */
    int bg = 0;              /* Background job? */

    buf[strlen(buf) - 1] = ' ';  /* Replace trailing '\n' with space */
    while (*buf && (*buf == ' ')) /* Ignore leading spaces */
        buf++;

    /* Build the argv list */
    *argc = 0;
    while ((delim = strchr(buf, ' '))) {
        argv[(*argc)++] = buf;
        *delim = '\0';
        buf = delim + 1;
        while (*buf && (*buf == ' ')) /* Ignore spaces */
            buf++;
    }
    argv[*argc] = NULL;

    if ((*argc) == 0)  /* Ignore blank line */
        return 1;

    /* Should the job pipe_command in the background? */
    // command 끝에 &를 달고 있다면, argv가 이를 제거한 상태로 들고 있도록 작업
    int last_ind = (int)strlen(argv[(*argc) - 1]) - 1;
    if ((bg = (*argv[(*argc) - 1] == '&')) != 0){
        argv[(*argc) - 1][1] = '\0';
        argv[--(*argc)] = NULL;
        return 1;
    }
    if (argv[(*argc)-1][0] != '\0' && argv[(*argc)-1][last_ind] == '&'){
        argv[(*argc)-1][last_ind] = '\0';
        argv[(*argc)] = NULL;
        return 1;
    }
    return bg;
}
/* $end parseline */


void change_dir(int argc, char **argv) {
    if ((argc != 2) || chdir(argv[1]) == -1) {
        printf("cd argument err!\n");
    }
}


int pipe_command(char*cmd, char **argv, int input, PCMD_TYPE pipe_type, pid_t *pid){
    tokenize_for_pipe_command(cmd, argv);

    int fd[2];
    if (pipe(fd) < 0){
        printf("Piping err!\n");
        return -1;
    }
    *pid = fork();

    if ((*pid) == 0) { // child process
        if (pipe_type == FIRST && input == 0){
            dup2(fd[1], STDOUT_FILENO);
        }
        else if (pipe_type == MIDDLE && input != 0){
            dup2(input, STDIN_FILENO);
            dup2(fd[1], STDOUT_FILENO);
        }
        else{ // LAST
            dup2(input, STDIN_FILENO);
        }

        if ((execvp(argv[0], argv)) == -1){
            printf("execvp err!\n");
            exit(1);
        }
    }

    if (input != 0) close(input);
    close(fd[1]);
    if (pipe_type == LAST) close(fd[0]);
    return fd[0];
}


void tokenize_for_pipe_command(char *cmd, char** argv){
    // 공백 제거
    while (isspace(*cmd)) cmd++;

    char* nxt = strchr(cmd, ' ');
    int ind = 0;

    while (nxt != NULL){
        nxt[0] = '\0';
        argv[ind++] = cmd;
        while (isspace(*(nxt + 1))) nxt++;
        cmd = nxt + 1;
        nxt = strchr(cmd, ' ');
    }

    if (cmd[0] != '\0') {
        argv[ind] = cmd;
        nxt = strchr(cmd, '\n');
        if (nxt[0] != '\0') nxt[0] = '\0';
        ind++;
    }

    // grep 명령과 함께 입력되는 쌍따움표 "" 혹은 따움표에 대한 '' 처리
    if ((argv[ind - 1][0] == '\"' && argv[ind - 1][strlen(argv[ind - 1]) - 1] == '\"') ||
        (argv[ind - 1][0] == '\'' && argv[ind - 1][strlen(argv[ind - 1]) - 1] == '\'')){
        argv[ind - 1][strlen(argv[ind - 1]) - 1] = '\0';
        argv[ind - 1] = &(argv[ind - 1][0]) + 1;
    }
    argv[ind] = NULL;
}