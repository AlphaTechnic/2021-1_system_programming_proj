//
// Created by 김주호 on 2021/05/31.
//

#ifndef SP_PROJ4_MYSHELL_H
#define SP_PROJ4_MYSHELL_H

/* $begin shellmain */
#include "csapp.h"
#include <stdlib.h>
#include <signal.h>
#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
#include <ctype.h>

#define MAXARGS   128
#define MAXJOBS   32

// pipe command의 유형을 3가지로 분류 (머리 - 몸통 - 꼬리)
// pipe structure : FIRST - MIDDLE - ... - MIDDLE - LAST
typedef enum PCMD_TYPE {
    FIRST = 0,
    MIDDLE = 1,
    LAST = 2
}PCMD_TYPE;

int PRINT_FOR_DEBUG = 0;

/* Function prototypes */
void eval(char *cmdline);
int parseline(char *buf, int *argc, char **argv);
int builtin_command(int argc, char **argv);

// phase 1
void change_dir(int argc, char **argv);

// phase 2
int pipe_command(char*cmd, char **argv, int input, PCMD_TYPE pipe_type, pid_t *pid);
void tokenize_for_pipe_command(char *cmd, char **argv);


#endif //SP_PROJ4_MYSHELL_H
