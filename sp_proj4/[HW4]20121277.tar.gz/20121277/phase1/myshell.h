//
// Created by 김주호 on 2021/05/31.
//

#ifndef SP_PROJ4_MYSHELL_H
#define SP_PROJ4_MYSHELL_H

/* $begin shellmain */
#include "csapp.h"
#include <stdlib.h>
#include <signal.h>
#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
#include <ctype.h>

#define MAXARGS   128

int PRINT_FOR_DEBUG = 0;

/* Function prototypes */
void eval(char *cmdline);
int parseline(char *buf, int *argc, char **argv);
int builtin_command(int argc, char **argv);

// phase 1
void change_dir(int argc, char **argv);


#endif //SP_PROJ4_MYSHELL_H
